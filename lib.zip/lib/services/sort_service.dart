import "../models/form_entry.dart";
import "../models/sort_state.dart";

class SortService {
  /// Updates the list of [SortState]s based on user interaction with a column header.
  ///
  /// This method cycles the sort direction of the given [column] in the order:
  /// none → ascending → descending → none.
  ///
  /// If the column is already in the sort order, its previous state is removed.
  /// If the new direction is not `none`, the column is reinserted at its previous index,
  /// maintaining the sequence in which columns were clicked.
  ///
  /// This preserves the sort precedence order without re-prioritizing columns,
  /// allowing stable cascading multi-column sorting based on click sequence.
  List<SortState> updateSortOrder({
    required List<SortState> currentOrder,
    required Field column,
  }) {
    // Check if the column is already in the current sort order.
    // If not found, return a default SortState with no direction.
    final existingIndex = currentOrder.indexWhere((s) => s.column == column);
    final currentDirection = existingIndex == -1
        ? SortDirection.none
        : currentOrder[existingIndex].direction;

    // Determine the next sort direction in the tri-state cycle:
    SortDirection nextDirection = switch (currentDirection) {
      SortDirection.none => SortDirection.asc,
      SortDirection.asc => SortDirection.desc,
      SortDirection.desc => SortDirection.none,
    };

    // Copy state (follow rules for keeping state immutable)
    final newSortOrder = List<SortState>.from(currentOrder);

    // If column's sort state existed, remove it from the list
    if (existingIndex != -1) {
      newSortOrder.removeAt(existingIndex);
    }

    // If the direction is declared, insert the new sort state in its old position for this column
    if (nextDirection != SortDirection.none) {
      final insertIndex = existingIndex != -1
          ? existingIndex
          : newSortOrder.length;
      newSortOrder.insert(
        insertIndex,
        SortState(column: column, direction: nextDirection),
      );
    }

    return newSortOrder;
  }

  /// Sorts the provided list of [FormEntry] items according to the given [sortOrder].
  ///
  /// Performs a cascading, multi-column sort: it iterates through the [sortOrder] list,
  /// comparing each pair of entries by the specified column in sequence. If two entries
  /// are equal on one column, the next column in the sequence is used to break ties.
  ///
  /// - [items]: The original list of entries to sort. A new sorted list is returned,
  ///   and the input list remains unmodified.
  /// - [sortOrder]: A list of [SortState] objects indicating which columns to sort by
  ///   and in which direction (ascending or descending). An empty [sortOrder] returns
  ///   the data in its original order.
  ///
  /// Returns a new `List<FormEntry>` sorted according to the specified order.

  List<FormEntry> applySort({
    required List<FormEntry> items,
    required List<SortState> sortOrder,
  }) {
    // Copy state (follow rules for keeping state immutable)
    final newItems = List<FormEntry>.from(items);

    // Apply cascading sort based on the provided sort order.
    newItems.sort((a, b) {
      for (final sort in sortOrder) {
        final aVal = a[sort.column];
        final bVal = b[sort.column];
        final result = aVal.compareTo(bVal);
        if (result != 0) {
          return sort.direction == SortDirection.asc ? result : -result;
        }
      }
      return 0;
    });

    return newItems;
  }
}
