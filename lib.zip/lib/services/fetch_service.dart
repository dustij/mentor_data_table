import "../data/fetch_policy.dart";
import "../models/form_entry.dart";

class FetchService {
  final FetchPolicy policy;

  FetchService({required this.policy});

  Future<List<FormEntry>> fetch() {
    return policy.fetch();
  }
}
