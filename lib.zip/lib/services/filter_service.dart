import "../models/filter_query.dart";
import "../models/form_entry.dart";

class FilterService {
  List<FormEntry> applyFilter({
    required List<FormEntry> items,
    required FilterQuery filter,
  }) {
    return items.where((e) => filter.matches(e)).toList();
  }
}

class FilterBuilder {
  final List<FilterQuery> _clauses = [];

  FilterBuilder whereContains({required Field column, required String text}) {
    _clauses.add(FieldContains(column, text));
    return this;
  }

  FilterBuilder whereEquals({required Field column, required String text}) {
    _clauses.add(FieldEquals(column, text));
    return this;
  }

  /// Adds an OR group of arbitrary filter clauses.
  FilterBuilder orGroup(List<FilterQuery> clauses) {
    _clauses.add(OrFilter(clauses));
    return this;
  }

  FilterQuery build() {
    return AndFilter(_clauses);
  }
}
