import "form_entry.dart";

enum FilterOperator { includes, equals }

class FilterRule {
  final Field field;
  final String text;
  final FilterOperator operator;

  FilterRule({required this.field, required this.text, required this.operator});
}
