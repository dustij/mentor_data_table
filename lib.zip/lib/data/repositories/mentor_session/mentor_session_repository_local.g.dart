// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mentor_session_repository_local.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$mentorSessionRepositoryLocalHash() =>
    r'85eaee2ba5bf9e9b7843f76b8e5ca546b92cef4b';

/// See also [MentorSessionRepositoryLocal].
@ProviderFor(MentorSessionRepositoryLocal)
final mentorSessionRepositoryLocalProvider =
    AutoDisposeAsyncNotifierProvider<
      MentorSessionRepositoryLocal,
      List<MentorSession>
    >.internal(
      MentorSessionRepositoryLocal.new,
      name: r'mentorSessionRepositoryLocalProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$mentorSessionRepositoryLocalHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$MentorSessionRepositoryLocal =
    AutoDisposeAsyncNotifier<List<MentorSession>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
