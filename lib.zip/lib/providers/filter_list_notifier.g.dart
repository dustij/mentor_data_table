// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'filter_list_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$filterListNotifierHash() =>
    r'792a6749645e143bc594a9ae502767e7185e8a62';

/// See also [FilterListNotifier].
@ProviderFor(FilterListNotifier)
final filterListNotifierProvider =
    AutoDisposeNotifierProvider<FilterListNotifier, List<Filter>>.internal(
      FilterListNotifier.new,
      name: r'filterListNotifierProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$filterListNotifierHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$FilterListNotifier = AutoDisposeNotifier<List<Filter>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
