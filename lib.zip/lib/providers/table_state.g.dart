// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'table_state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$tableStateHash() => r'b4db0c018189a98200375c71245ad32f59a4f46b';

/// See also [tableState].
@ProviderFor(tableState)
final tableStateProvider = AutoDisposeFutureProvider<List<Entry>>.internal(
  tableState,
  name: r'tableStateProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$tableStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef TableStateRef = AutoDisposeFutureProviderRef<List<Entry>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
