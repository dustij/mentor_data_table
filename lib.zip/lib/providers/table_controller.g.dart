// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'table_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$tableControllerHash() => r'b91784190b0b818e9a7ac7cd64b955e3cac4ae04';

/// See also [TableController].
@ProviderFor(TableController)
final tableControllerProvider =
    AutoDisposeAsyncNotifierProvider<TableController, TableState>.internal(
      TableController.new,
      name: r'tableControllerProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$tableControllerHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$TableController = AutoDisposeAsyncNotifier<TableState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
