import "package:hooks_riverpod/hooks_riverpod.dart";
import "package:riverpod_annotation/riverpod_annotation.dart";

import "package:mentor_data_table/models/entry.dart";
import "package:mentor_data_table/providers/filter_list_notifier.dart";
import "package:mentor_data_table/providers/original_data.dart";
import "package:mentor_data_table/providers/sort_list_notifier.dart";
import "package:mentor_data_table/util/table_processor.dart";

// to generate run: `dart run build_runner build --delete-conflicting-outputs`
part "table_state.g.dart";

@riverpod
Future<List<Entry>> tableState(Ref ref) async {
  final orignalData = await ref.watch(originalDataProvider.future);

  final filterList = ref.watch(filterListNotifierProvider);
  final sortList = ref.watch(sortListNotifierProvider);

  final filteredData = TableProcessor.applyFilters(orignalData, filterList);
  final sortedData = TableProcessor.applySort(filteredData, sortList);

  return sortedData;
}
