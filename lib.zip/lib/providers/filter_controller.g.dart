// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'filter_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$filterControllerHash() => r'340b548da15052f42418076d7be0a9affe1a36b7';

/// See also [FilterController].
@ProviderFor(FilterController)
final filterControllerProvider =
    AutoDisposeNotifierProvider<FilterController, FilterQuery>.internal(
      FilterController.new,
      name: r'filterControllerProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$filterControllerHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$FilterController = AutoDisposeNotifier<FilterQuery>;
String _$filterBuilderHash() => r'c2c75c8eeabe2e6174666bdfee09f174bb93a988';

/// Fluent builder for constructing a composite [FilterQuery] via method chaining.
///
/// Copied from [_FilterBuilder].
@ProviderFor(_FilterBuilder)
final _filterBuilderProvider =
    AutoDisposeNotifierProvider<_FilterBuilder, _FilterBuilder>.internal(
      _FilterBuilder.new,
      name: r'_filterBuilderProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$filterBuilderHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$FilterBuilder = AutoDisposeNotifier<_FilterBuilder>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
