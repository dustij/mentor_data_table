import "package:mentor_data_table/models/filter_rule.dart";
import "package:mentor_data_table/providers/filter_controller.dart";
import "package:riverpod_annotation/riverpod_annotation.dart";

import "../data/example_policy.dart";
import "../models/filter_query.dart";
import "../models/form_entry.dart";
import "../models/sort_state.dart";
import "../models/table_state.dart";
import "../services/fetch_service.dart";
import "../services/filter_service.dart";
import "../services/sort_service.dart";

// Generated code lives in part
// to generate run: `flutter pub run build_runner build --delete-conflicting-outputs`
part "table_controller.g.dart";

/// Manages the state of the data table, including:
/// - asynchronous loading of entries,
/// - multi-column sorting,
/// - searching and composable filters,
/// - updating the result set in [TableState].
@riverpod
class TableController extends _$TableController {
  /// Loads all entries via [FetchService] and initializes [TableState]
  /// with unfiltered, unsorted data.
  @override
  FutureOr<TableState> build() async {
    // simulated delay, don't ship in production
    // await Future.delayed(const Duration(seconds: 2));
    final data = await FetchService(policy: ExamplePolicy()).fetch();
    return TableState(
      originalData: data,
      resultSet: data,
      sortOrder: [],
      filter: MatchAllFilter(),
    );
  }

  void toggleSort(Field column) {
    final current = state.requireValue;
    final sortSvc = SortService();

    final updatedSort = sortSvc.updateSortOrder(
      currentOrder: current.sortOrder,
      column: column,
    );

    _setState(sortOrder: updatedSort);
  }

  void search(String text) {
    ref.read(filterControllerProvider.notifier).applySearchFilter(text);
    final query = ref.read(filterControllerProvider);

    _setState(filter: query);
  }

  void addFilter(FilterRule filter) {
    ref.read(filterControllerProvider.notifier).addFilter(filter);
    final query = ref.read(filterControllerProvider);

    _setState(filter: query);
  }

  void _setState({
    List<FormEntry>? items,
    FilterQuery? filter,
    List<SortState>? sortOrder,
  }) {
    final current = state.requireValue;
    final sortSvc = SortService();
    final filterSvc = FilterService();

    items ??= current.originalData;
    filter ??= current.filter;
    sortOrder ??= current.sortOrder;

    // Apply filter
    final filtered = filterSvc.applyFilter(items: items, filter: filter);

    // Sort filterd data
    final List<FormEntry> resultSet;
    if (sortOrder.isEmpty) {
      resultSet = filtered;
    } else {
      resultSet = sortSvc.applySort(items: filtered, sortOrder: sortOrder);
    }

    state = AsyncData(
      current.copyWith(
        filter: filter,
        sortOrder: sortOrder,
        resultSet: resultSet,
      ),
    );
  }
}
