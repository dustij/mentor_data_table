// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'processed_data.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$processedDataHash() => r'bf84c7207a052bc9fd404b8ba6b0dcf6e2faaaa8';

/// See also [ProcessedData].
@ProviderFor(ProcessedData)
final processedDataProvider =
    AutoDisposeNotifierProvider<
      ProcessedData,
      AsyncValue<List<Entry>>
    >.internal(
      ProcessedData.new,
      name: r'processedDataProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$processedDataHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$ProcessedData = AutoDisposeNotifier<AsyncValue<List<Entry>>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
