// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'table_viewmodel.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$tableViewModelHash() => r'eff3a12ef334f712c6d88731689b937891deb90e';

/// See also [TableViewModel].
@ProviderFor(TableViewModel)
final tableViewModelProvider =
    AutoDisposeAsyncNotifierProvider<TableViewModel, TableState>.internal(
      TableViewModel.new,
      name: r'tableViewModelProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$tableViewModelHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$TableViewModel = AutoDisposeAsyncNotifier<TableState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
