import "package:flutter/material.dart";

import "package:hooks_riverpod/hooks_riverpod.dart";

class FilterMenu extends ConsumerWidget {
  final void Function() onClose;

  const FilterMenu({super.key, required this.onClose});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container();
  }
}
