import "dart:async";

import "package:flutter/material.dart";

import "package:flutter_hooks/flutter_hooks.dart";
import "package:hooks_riverpod/hooks_riverpod.dart";

import "package:mentor_data_table/models/entry.dart";
import "package:mentor_data_table/providers/table_state.dart";
import "package:mentor_data_table/util/table_processor.dart";

class TableSearchBar extends HookConsumerWidget {
  const TableSearchBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = useTextEditingController();

    final tableStateAsync = ref.watch(tableStateProvider);
    final currentEntries = tableStateAsync.maybeWhen(
      data: (entries) => entries,
      orElse: () => <Entry>[],
    );

    onSearch(text) => TableProcessor.applySearch(currentEntries, text);

    useDebouncedSearch(controller, onSearch);

    return Container(
      padding: const EdgeInsets.all(8.0),
      child: SearchBar(
        hintText: "Search",
        controller: controller,
        onSubmitted: onSearch,
        trailing: controller.text.isNotEmpty
            ? [
                IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    controller.clear();
                    onSearch("");
                  },
                ),
              ]
            : null,
        padding: const WidgetStatePropertyAll(
          EdgeInsets.symmetric(horizontal: 16.0),
        ),
        leading: const Icon(Icons.search),
      ),
    );
  }
}

void useDebouncedSearch(
  TextEditingController controller,
  void Function(String) onSearch, {
  Duration delay = const Duration(milliseconds: 300),
}) {
  final debounce = useRef<Timer?>(null);

  useEffect(() {
    void listener() {
      debounce.value?.cancel();
      debounce.value = Timer(delay, () {
        onSearch(controller.text);
      });
    }

    controller.addListener(listener);
    return () {
      controller.removeListener(listener);
      debounce.value?.cancel();
    };
  }, [controller]);
}
